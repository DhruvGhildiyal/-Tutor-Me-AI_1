"""Local development entry point. Do NOT use this to run in production —
use `wsgi.py` behind gunicorn/uwsgi instead (see README)."""
from app import create_app

app = create_app("development")

if __name__ == "__main__":
    app.run(debug=True, threaded=True)

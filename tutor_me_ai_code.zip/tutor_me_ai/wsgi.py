"""Production WSGI entry point.

Run with:  gunicorn -w 4 -b 0.0.0.0:8000 wsgi:app

Requires SECRET_KEY, DATABASE_URL, and GEMINI_API_KEY set as real
environment variables (not a .env file) - see app/config.py:ProductionConfig.
"""
from app import create_app

app = create_app("production")

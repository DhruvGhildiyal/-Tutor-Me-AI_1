import io
from unittest.mock import patch

from app.ai import AIError


def test_api_requires_login_returns_json_401(client):
    resp = client.post("/api/ask", json={"question": "hi"})
    assert resp.status_code == 401
    assert resp.get_json()["error"]


@patch("app.blueprints.tools.ask_text", return_value="**Bold** answer")
def test_ask_returns_rendered_markdown(mock_ask, auth_client):
    resp = auth_client.post("/api/ask", json={"question": "What is gravity?"})
    assert resp.status_code == 200
    body = resp.get_json()
    assert "<strong>Bold</strong>" in body["result"] or "<b>" in body["result"]


def test_ask_rejects_empty_question(auth_client):
    resp = auth_client.post("/api/ask", json={"question": "   "})
    assert resp.status_code == 400


@patch("app.blueprints.tools.ask_text", side_effect=AIError("AI is down right now."))
def test_ask_surfaces_ai_error_as_502(mock_ask, auth_client):
    resp = auth_client.post("/api/ask", json={"question": "hi"})
    assert resp.status_code == 502
    assert "AI is down" in resp.get_json()["error"]


@patch(
    "app.blueprints.tools.ask_structured",
    return_value={
        "questions": [
            {"question": "2+2?", "options": ["3", "4", "5", "6"], "correct_index": 1, "explanation": "Basic arithmetic."}
        ]
    },
)
def test_mcq_returns_structured_questions(mock_struct, auth_client):
    resp = auth_client.post("/api/mcq", json={"content": "Addition basics", "num": 1})
    assert resp.status_code == 200
    data = resp.get_json()
    assert len(data["questions"]) == 1
    assert data["questions"][0]["correct_index"] == 1


def test_assignment_rejects_unsupported_extension(auth_client):
    data = {"file": (io.BytesIO(b"hello"), "notes.exe"), "mode": "Short"}
    resp = auth_client.post("/api/assignment", data=data, content_type="multipart/form-data")
    assert resp.status_code == 400


def test_assignment_requires_file(auth_client):
    resp = auth_client.post("/api/assignment", data={"mode": "Short"}, content_type="multipart/form-data")
    assert resp.status_code == 400


@patch("app.blueprints.tools.ask_text", return_value="Solved answer")
def test_assignment_txt_file_is_solved(mock_ask, auth_client):
    data = {"file": (io.BytesIO(b"Q1: What is 2+2?"), "hw.txt"), "mode": "Short"}
    resp = auth_client.post("/api/assignment", data=data, content_type="multipart/form-data")
    assert resp.status_code == 200
    assert "Solved" in resp.get_json()["result"]


def test_notes_crud_flow(auth_client):
    resp = auth_client.post("/api/notes", json={"content": "Remember to revise chapter 4"})
    assert resp.status_code == 200

    resp = auth_client.get("/api/notes")
    notes = resp.get_json()["notes"]
    assert len(notes) == 1
    note_id = notes[0]["id"]

    resp = auth_client.delete(f"/api/notes/{note_id}")
    assert resp.status_code == 200

    resp = auth_client.get("/api/notes")
    assert resp.get_json()["notes"] == []


def test_notes_are_scoped_per_user(client, app):
    # user A
    client.post("/register", data={"username": "userA", "email": "a@example.com", "password": "password1", "confirm_password": "password1"})
    client.post("/api/notes", json={"content": "A's secret note"})
    client.get("/logout")

    # user B should not see A's notes
    client.post("/register", data={"username": "userB", "email": "b@example.com", "password": "password1", "confirm_password": "password1"})
    resp = client.get("/api/notes")
    assert resp.get_json()["notes"] == []


def test_history_records_tool_usage(auth_client):
    with patch("app.blueprints.tools.ask_text", return_value="Answer text"):
        auth_client.post("/api/ask", json={"question": "hello"})
    resp = auth_client.get("/api/history")
    history = resp.get_json()["history"]
    assert len(history) == 1
    assert history[0]["tool"] == "Ask AI"


def test_ai_output_is_sanitised_against_xss():
    from app.utils import render_ai_markdown

    dangerous = "Here you go <script>alert('xss')</script> **bold**"
    rendered = render_ai_markdown(dangerous)
    assert "<script>" not in rendered
    assert "<strong>bold</strong>" in rendered

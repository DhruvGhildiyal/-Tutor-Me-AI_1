from app.models import User


def test_register_creates_user(client, app):
    resp = client.post(
        "/register",
        data={"username": "alice", "email": "alice@example.com", "password": "password1", "confirm_password": "password1"},
        follow_redirects=True,
    )
    assert resp.status_code == 200
    with app.app_context():
        assert User.query.filter_by(username="alice").first() is not None


def test_register_hashes_password_not_plaintext(app, client):
    client.post(
        "/register",
        data={"username": "bob", "email": "bob@example.com", "password": "password1", "confirm_password": "password1"},
        follow_redirects=True,
    )
    with app.app_context():
        user = User.query.filter_by(username="bob").first()
        assert user.password_hash != "password1"
        assert user.check_password("password1")
        assert not user.check_password("wrongpassword")


def test_register_rejects_duplicate_username(client, registered_user):
    client.get("/logout")  # registering auto-logs-in; log out so /register isn't redirected away
    resp = client.post(
        "/register",
        data={"username": registered_user["username"], "email": "different@example.com", "password": "password1", "confirm_password": "password1"},
        follow_redirects=True,
    )
    assert b"already taken" in resp.data


def test_register_rejects_mismatched_passwords(client):
    resp = client.post(
        "/register",
        data={"username": "carl", "email": "carl@example.com", "password": "password1", "confirm_password": "password2"},
    )
    assert b"must match" in resp.data


def test_register_rejects_short_password(client):
    resp = client.post(
        "/register",
        data={"username": "dave", "email": "dave@example.com", "password": "123", "confirm_password": "123"},
    )
    assert resp.status_code == 200  # re-renders form with validation error
    with client.application.app_context():
        assert User.query.filter_by(username="dave").first() is None


def test_login_success(client, registered_user):
    resp = client.post(
        "/login",
        data={"identifier": registered_user["username"], "password": registered_user["password"]},
        follow_redirects=True,
    )
    assert b"Dashboard" in resp.data or resp.status_code == 200


def test_login_wrong_password_fails(client, registered_user):
    client.get("/logout")  # registering auto-logs-in; log out so /login isn't redirected away
    resp = client.post(
        "/login",
        data={"identifier": registered_user["username"], "password": "totally-wrong"},
    )
    assert b"Invalid username" in resp.data


def test_dashboard_requires_login(client):
    resp = client.get("/dashboard", follow_redirects=True)
    assert b"log in" in resp.data.lower() or b"login" in resp.data.lower()


def test_logout_clears_session(auth_client):
    auth_client.get("/logout")
    resp = auth_client.get("/dashboard", follow_redirects=True)
    assert b"login" in resp.data.lower() or b"log in" in resp.data.lower()

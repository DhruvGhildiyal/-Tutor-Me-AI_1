import pytest

from app import create_app
from app.extensions import db as _db


@pytest.fixture()
def app():
    app = create_app("testing")
    with app.app_context():
        _db.create_all()
        yield app
        _db.session.remove()
        _db.drop_all()


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def registered_user(client):
    payload = {"username": "testuser", "email": "test@example.com", "password": "secret123", "confirm_password": "secret123"}
    client.post("/register", data=payload, follow_redirects=True)
    return payload


@pytest.fixture()
def auth_client(client, registered_user):
    """A client that's already logged in as registered_user."""
    client.post("/login", data={"identifier": registered_user["username"], "password": registered_user["password"]}, follow_redirects=True)
    return client

"""
Thin, defensive wrapper around the Gemini API.

Design choices that matter here:
  - A missing/invalid API key fails fast with a clear message, distinct from
    a transient network error, distinct from the model refusing content.
  - Structured endpoints (MCQ, question paper) pass response_schema so the
    model is constrained to return valid JSON we can trust, instead of
    "did my regex happen to parse the markdown" like the original version.
  - Every call has a hard timeout so a stalled request can't hang a worker
    forever.
  - All failures are logged server-side with enough detail to debug, while
    the user only ever sees a safe, generic message.
"""
import json
import logging
import time

from flask import current_app

logger = logging.getLogger(__name__)

try:
    from google import genai
    from google.genai import types
    from google.genai import errors as genai_errors
except ImportError:  # pragma: no cover - exercised only if dependency missing
    genai = None
    types = None
    genai_errors = None


class AIError(Exception):
    """Raised for any AI-call failure. `user_message` is safe to show the user."""

    def __init__(self, user_message, log_message=None):
        super().__init__(log_message or user_message)
        self.user_message = user_message


def _get_client():
    api_key = current_app.config.get("GEMINI_API_KEY")
    if genai is None:
        raise AIError(
            "The AI backend library isn't installed on the server.",
            "google-genai package not importable",
        )
    if not api_key:
        raise AIError(
            "The server isn't configured with a GEMINI_API_KEY yet. "
            "Add one to your .env file (see .env.example).",
            "GEMINI_API_KEY missing",
        )
    return genai.Client(api_key=api_key)


def _call(contents, response_schema=None, retries=3, backoff_seconds=2, timeout_ms=30000):
    client = _get_client()
    model = current_app.config.get("GEMINI_MODEL", "gemini-2.5-flash")

    config_kwargs = {
        "thinking_config": types.ThinkingConfig(thinking_budget=0),
        "http_options": types.HttpOptions(timeout=timeout_ms),
    }
    if response_schema is not None:
        config_kwargs["response_mime_type"] = "application/json"
        config_kwargs["response_schema"] = response_schema

    last_error = None
    for attempt in range(1, retries + 1):
        try:
            response = client.models.generate_content(
                model=model,
                contents=contents,
                config=types.GenerateContentConfig(**config_kwargs),
            )
            if not response.text:
                raise AIError(
                    "The AI didn't return a usable response. Please try again.",
                    "empty response.text from Gemini",
                )
            return response.text
        except AIError:
            raise
        except Exception as exc:  # noqa: BLE001 - genai raises several exception types
            last_error = exc
            status = getattr(exc, "code", None) or getattr(exc, "status_code", None)
            logger.warning("Gemini call failed (attempt %s/%s, status=%s): %s",
                            attempt, retries, status, exc)
            if status in (400, 401, 403):
                # Bad request / auth problems will never succeed on retry.
                raise AIError(
                    "The AI service rejected the request (check your API key "
                    "or the input content).",
                    f"Gemini {status} error: {exc}",
                ) from exc
            if attempt < retries:
                time.sleep(backoff_seconds * attempt)

    logger.error("Gemini call failed after %s attempts: %s", retries, last_error)
    raise AIError(
        "The AI service is temporarily unavailable. Please try again shortly.",
        f"Gemini call exhausted retries: {last_error}",
    )


def ask_text(prompt: str) -> str:
    """Free-text generation for the conversational tools."""
    return _call(prompt)


def ask_structured(prompt: str, schema: dict) -> dict:
    """Structured generation. Returns a parsed dict guaranteed to (attempt to)
    match `schema`. Raises AIError if the model's output isn't valid JSON -
    we do NOT try to regex-repair bad JSON, since that just hides model
    failures behind fragile string surgery."""
    raw = _call(prompt, response_schema=schema)
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError) as exc:
        logger.error("Gemini structured response wasn't valid JSON: %s", raw[:500])
        raise AIError(
            "The AI returned data in an unexpected format. Please try again.",
            f"JSON decode failure: {exc}",
        ) from exc

import datetime
import os
from functools import wraps

from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user

from app.extensions import db, limiter
from app.ai import ask_text, ask_structured, AIError
from app.models import Note, HistoryItem
from app.utils import render_ai_markdown, extract_text_from_upload, UnsupportedFileType, save_history
from app import prompts

tools_bp = Blueprint("tools", __name__)


def handle_ai_errors(f):
    """Turns AIError into a clean 502 JSON response and logs unexpected
    exceptions instead of leaking a stack trace to the client."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except AIError as e:
            current_app.logger.warning("AIError in %s: %s", f.__name__, e)
            return jsonify({"error": e.user_message}), 502
        except UnsupportedFileType as e:
            return jsonify({"error": str(e)}), 400
    return wrapper


def _require_json_field(data, field):
    value = (data or {}).get(field)
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    return value


def _validated_upload():
    """Shared upload validation for all file-accepting endpoints."""
    if "file" not in request.files:
        return None, (jsonify({"error": "No file uploaded."}), 400)
    file_storage = request.files["file"]
    if not file_storage.filename:
        return None, (jsonify({"error": "No file selected."}), 400)
    ext = os.path.splitext(file_storage.filename.lower())[1]
    allowed = current_app.config.get("UPLOAD_EXTENSIONS", {".txt", ".docx", ".pdf"})
    if ext not in allowed:
        return None, (jsonify({"error": f"Unsupported file type '{ext}'. Use .txt, .docx, or .pdf"}), 400)
    return file_storage, None


# ---------------------------------------------------------------------------
# Free-text tools
# ---------------------------------------------------------------------------

@tools_bp.route("/ask", methods=["POST"])
@login_required
@limiter.limit("30 per hour")
@handle_ai_errors
def api_ask():
    data = request.get_json(silent=True) or {}
    question = _require_json_field(data, "question")
    if not question:
        return jsonify({"error": "Question is required."}), 400

    answer = ask_text(prompts.ask_prompt(question))
    save_history("Ask AI", question, answer)
    return jsonify({"result": render_ai_markdown(answer)})


@tools_bp.route("/assignment", methods=["POST"])
@login_required
@limiter.limit("15 per hour")
@handle_ai_errors
def api_assignment():
    file_storage, error = _validated_upload()
    if error:
        return error
    mode = request.form.get("mode", "Short")

    content = extract_text_from_upload(file_storage)
    if not content.strip():
        return jsonify({"error": "Couldn't find any readable text in that file."}), 400

    answer = ask_text(prompts.assignment_prompt(content, mode))
    save_history("Assignment Solver", mode, answer)
    return jsonify({"result": render_ai_markdown(answer)})


@tools_bp.route("/explain", methods=["POST"])
@login_required
@limiter.limit("30 per hour")
@handle_ai_errors
def api_explain():
    data = request.get_json(silent=True) or {}
    content = _require_json_field(data, "content")
    if not content:
        return jsonify({"error": "Content is required."}), 400

    answer = ask_text(prompts.explain_prompt(content))
    save_history("Content Explainer", content[:200], answer)
    return jsonify({"result": render_ai_markdown(answer)})


@tools_bp.route("/summarize-pdf", methods=["POST"])
@login_required
@limiter.limit("15 per hour")
@handle_ai_errors
def api_summarize_pdf():
    file_storage, error = _validated_upload()
    if error:
        return error

    content = extract_text_from_upload(file_storage)
    if not content.strip():
        return jsonify({"error": "Couldn't find any readable text in that file."}), 400

    answer = ask_text(prompts.summarize_prompt(content))
    save_history("PDF Summary", file_storage.filename, answer)
    return jsonify({"result": render_ai_markdown(answer)})


@tools_bp.route("/tip", methods=["POST"])
@login_required
@limiter.limit("10 per hour")
@handle_ai_errors
def api_tip():
    today = datetime.datetime.now().strftime("%d %B %Y")
    answer = ask_text(prompts.tip_prompt(today))
    save_history("Daily Tip", today, answer)
    return jsonify({"result": render_ai_markdown(answer)})


@tools_bp.route("/quote", methods=["POST"])
@login_required
@limiter.limit("10 per hour")
@handle_ai_errors
def api_quote():
    today = datetime.datetime.now().strftime("%d %B %Y")
    answer = ask_text(prompts.quote_prompt(today))
    save_history("Daily Quote", today, answer)
    return jsonify({"result": render_ai_markdown(answer)})


@tools_bp.route("/career", methods=["POST"])
@login_required
@limiter.limit("15 per hour")
@handle_ai_errors
def api_career():
    data = request.get_json(silent=True) or {}
    profession = _require_json_field(data, "profession")
    if not profession:
        return jsonify({"error": "Profession is required."}), 400
    user_type = data.get("user_type", "student")

    answer = ask_text(prompts.career_prompt(profession, user_type))
    save_history("Career Roadmap", profession, answer)
    return jsonify({"result": render_ai_markdown(answer)})


@tools_bp.route("/books", methods=["POST"])
@login_required
@limiter.limit("15 per hour")
@handle_ai_errors
def api_books():
    data = request.get_json(silent=True) or {}
    subject = _require_json_field(data, "subject")
    if not subject:
        return jsonify({"error": "Subject is required."}), 400

    answer = ask_text(prompts.books_prompt(subject))
    save_history("Book Recommendations", subject, answer)
    return jsonify({"result": render_ai_markdown(answer)})


# ---------------------------------------------------------------------------
# Structured (JSON-schema) tools - these no longer trust free-text parsing
# ---------------------------------------------------------------------------

@tools_bp.route("/mcq", methods=["POST"])
@login_required
@limiter.limit("15 per hour")
@handle_ai_errors
def api_mcq():
    data = request.get_json(silent=True) or {}
    content = _require_json_field(data, "content")
    if not content:
        return jsonify({"error": "Content is required."}), 400
    num = data.get("num", 5)

    result = ask_structured(prompts.mcq_prompt(content, num), prompts.MCQ_SCHEMA)
    questions = result.get("questions", [])
    save_history("MCQ Generator", content[:200], f"{len(questions)} MCQs generated")
    return jsonify({"questions": questions})


@tools_bp.route("/question-paper", methods=["POST"])
@login_required
@limiter.limit("10 per hour")
@handle_ai_errors
def api_question_paper():
    data = request.get_json(silent=True) or {}
    subject = _require_json_field(data, "subject")
    if not subject:
        return jsonify({"error": "Subject is required."}), 400
    topic = data.get("topic", "General")
    marks = data.get("marks", 50)
    difficulty = data.get("difficulty", "Medium")

    paper = ask_structured(
        prompts.question_paper_prompt(subject, topic, marks, difficulty),
        prompts.QUESTION_PAPER_SCHEMA,
    )
    save_history("Question Paper", subject, f"Paper with {len(paper.get('sections', []))} sections")
    return jsonify({"paper": paper})


# ---------------------------------------------------------------------------
# Notes
# ---------------------------------------------------------------------------

@tools_bp.route("/notes", methods=["POST"])
@login_required
@limiter.limit("60 per hour")
def api_save_note():
    data = request.get_json(silent=True) or {}
    content = _require_json_field(data, "content")
    if not content:
        return jsonify({"error": "Note content is required."}), 400
    if len(content) > 10_000:
        return jsonify({"error": "Note is too long (max 10,000 characters)."}), 400

    note = Note(user_id=current_user.id, content=content)
    db.session.add(note)
    db.session.commit()
    return jsonify({"result": "Note saved."})


@tools_bp.route("/notes", methods=["GET"])
@login_required
def api_get_notes():
    page = max(request.args.get("page", 1, type=int), 1)
    per_page = 20
    pagination = (
        Note.query.filter_by(user_id=current_user.id)
        .order_by(Note.created_at.desc())
        .paginate(page=page, per_page=per_page, error_out=False)
    )
    return jsonify({
        "notes": [
            {"id": n.id, "content": n.content, "date": n.created_at.strftime("%d %b %Y %H:%M")}
            for n in pagination.items
        ],
        "page": page,
        "has_next": pagination.has_next,
    })


@tools_bp.route("/notes/<int:note_id>", methods=["DELETE"])
@login_required
def api_delete_note(note_id):
    note = Note.query.filter_by(id=note_id, user_id=current_user.id).first()
    if not note:
        return jsonify({"error": "Note not found."}), 404
    db.session.delete(note)
    db.session.commit()
    return jsonify({"result": "Note deleted."})


# ---------------------------------------------------------------------------
# History
# ---------------------------------------------------------------------------

@tools_bp.route("/history", methods=["GET"])
@login_required
def api_history():
    page = max(request.args.get("page", 1, type=int), 1)
    per_page = 20
    pagination = (
        HistoryItem.query.filter_by(user_id=current_user.id)
        .order_by(HistoryItem.created_at.desc())
        .paginate(page=page, per_page=per_page, error_out=False)
    )
    return jsonify({
        "history": [
            {
                "tool": h.tool,
                "prompt": h.prompt,
                "response": render_ai_markdown(h.response) if h.tool not in {"MCQ Generator", "Question Paper"} else h.response,
                "date": h.created_at.strftime("%d %b %Y %H:%M"),
            }
            for h in pagination.items
        ],
        "page": page,
        "has_next": pagination.has_next,
    })

from flask import Blueprint, render_template, redirect, url_for, flash, current_app
from flask_login import login_user, logout_user, login_required, current_user
from sqlalchemy.exc import IntegrityError

from app.extensions import db, limiter
from app.forms import RegisterForm, LoginForm
from app.models import User

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["GET", "POST"])
@limiter.limit("10 per hour")
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.dashboard"))

    form = RegisterForm()
    if form.validate_on_submit():
        username = form.username.data.strip()
        email = form.email.data.strip().lower()

        # Belt-and-suspenders: check first for a friendly message, but still
        # handle IntegrityError below in case of a race between two
        # concurrent signups with the same username/email.
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash("Username or email already taken.", "danger")
            return render_template("register.html", form=form)

        user = User(username=username, email=email)
        user.set_password(form.password.data)
        db.session.add(user)
        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            current_app.logger.warning("Duplicate registration race for username=%s", username)
            flash("Username or email already taken.", "danger")
            return render_template("register.html", form=form)

        login_user(user)
        current_app.logger.info("New user registered: %s", username)
        return redirect(url_for("dashboard.dashboard"))

    return render_template("register.html", form=form)


@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("20 per hour")
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.dashboard"))

    form = LoginForm()
    if form.validate_on_submit():
        identifier = form.identifier.data.strip()
        user = User.query.filter(
            (User.username == identifier) | (User.email == identifier.lower())
        ).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for("dashboard.dashboard"))
        # Deliberately vague: don't reveal whether the username or password
        # was the wrong part - that's an enumeration leak.
        flash("Invalid username/email or password.", "danger")

    return render_template("login.html", form=form)


@auth_bp.route("/logout")
@login_required
def logout():
    current_app.logger.info("User logged out: %s", current_user.username)
    logout_user()
    return redirect(url_for("dashboard.home"))

import os
import tempfile
import uuid

import bleach
import markdown as md_lib
from flask_login import current_user

from app.extensions import db
from app.models import HistoryItem

ALLOWED_TAGS = [
    "p", "br", "b", "strong", "i", "em", "ul", "ol", "li", "h1", "h2", "h3",
    "h4", "blockquote", "code", "pre", "table", "thead", "tbody", "tr", "th", "td", "a",
]
ALLOWED_ATTRS = {"a": ["href", "title", "rel"]}


def render_ai_markdown(text: str) -> str:
    """Convert AI-generated markdown to HTML and sanitise it before it ever
    reaches a template. AI output is untrusted input: if it ever echoes back
    something like a <script> tag from a prompt, bleach strips it rather
    than letting it execute in the user's browser."""
    if not text:
        return ""
    html = md_lib.markdown(text, extensions=["extra", "sane_lists"])
    return bleach.clean(html, tags=ALLOWED_TAGS, attributes=ALLOWED_ATTRS, strip=True)


class UnsupportedFileType(ValueError):
    pass


def extract_text_from_upload(file_storage, max_chars=50_000):
    """Extract text from an uploaded .txt/.docx/.pdf FileStorage.

    Uses a unique temp file per call (not a fixed shared filename) so
    concurrent uploads from different users can never collide or corrupt
    each other's data, and always cleans up in a `finally`.
    """
    filename = (file_storage.filename or "").lower()
    ext = os.path.splitext(filename)[1]

    if ext == ".txt":
        text = file_storage.read().decode("utf-8", errors="ignore")
    elif ext == ".docx":
        text = _extract_docx(file_storage)
    elif ext == ".pdf":
        text = _extract_pdf(file_storage)
    else:
        raise UnsupportedFileType("Unsupported file type. Use .txt, .docx, or .pdf")

    return text[:max_chars]


def _extract_docx(file_storage):
    import docx2txt

    fd, tmp_path = tempfile.mkstemp(prefix="upload_", suffix=f"_{uuid.uuid4().hex}.docx")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(file_storage.read())
        return docx2txt.process(tmp_path)
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


def _extract_pdf(file_storage):
    import fitz  # PyMuPDF

    data = file_storage.read()
    doc = fitz.open(stream=data, filetype="pdf")
    try:
        return "\n".join(page.get_text() for page in doc)
    finally:
        doc.close()


def save_history(tool, prompt, response):
    if not current_user.is_authenticated:
        return
    item = HistoryItem(
        user_id=current_user.id,
        tool=tool,
        prompt=(prompt or "")[:500],
        response=response,
    )
    db.session.add(item)
    db.session.commit()

"""
Centralised prompt templates and JSON schemas.

Keeping these separate from route handlers means:
  1. Prompts can be tuned/versioned without touching Flask logic.
  2. Anything that should return structured data (MCQs, question papers)
     gets a real JSON schema instead of "hope the model formats it nicely".
"""

# ---------------------------------------------------------------------------
# Free-text prompts (rendered as sanitised HTML)
# ---------------------------------------------------------------------------

def ask_prompt(question: str) -> str:
    return (
        "You are a patient, encouraging tutor. Answer the student's question "
        "clearly, with a short example if it helps understanding.\n\n"
        f"Question: {question}"
    )


def assignment_prompt(content: str, mode: str) -> str:
    mode = mode if mode in {"Short", "Detailed", "Step-by-step"} else "Short"
    return (
        f"Solve every question found in the text below, in {mode} style. "
        "Number your answers to match the question numbers.\n\n"
        f"{content}"
    )


def explain_prompt(content: str) -> str:
    return (
        "Explain the following content in simple terms a beginner could "
        f"follow, using an analogy if useful:\n\n{content}"
    )


def summarize_prompt(content: str) -> str:
    return (
        "Summarise the following lecture notes into clear bullet points, "
        f"grouped by topic:\n\n{content}"
    )


def tip_prompt(today: str) -> str:
    return f"Give one short, specific, motivational study tip for a student, dated {today}."


def quote_prompt(today: str) -> str:
    return f"Give one short motivational quote for students (with author if known), dated {today}."


def books_prompt(subject: str) -> str:
    return (
        f"Recommend 4-6 well-known books for learning {subject}. "
        "For each: title, author, why it's useful, and what topics it covers."
    )


def career_prompt(profession: str, user_type: str) -> str:
    return (
        f"Build a career roadmap for someone aiming to become a {profession} "
        f"(current status: {user_type}). Cover: key skills, a realistic "
        "timeline, and 2-3 recommended courses or certifications."
    )


# ---------------------------------------------------------------------------
# Structured (JSON) prompts + schemas
# ---------------------------------------------------------------------------

MCQ_SCHEMA = {
    "type": "object",
    "properties": {
        "questions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "question": {"type": "string"},
                    "options": {
                        "type": "array",
                        "items": {"type": "string"},
                        "minItems": 4,
                        "maxItems": 4,
                    },
                    "correct_index": {"type": "integer"},
                    "explanation": {"type": "string"},
                },
                "required": ["question", "options", "correct_index", "explanation"],
            },
        }
    },
    "required": ["questions"],
}


def mcq_prompt(content: str, num: int) -> str:
    num = max(1, min(int(num or 5), 25))
    return (
        f"Generate exactly {num} multiple-choice questions based on the "
        "content below. Each must have exactly 4 options, a zero-based "
        "correct_index, and a one-sentence explanation of the correct "
        f"answer. Respond only with JSON matching the required schema.\n\n{content}"
    )


QUESTION_PAPER_SCHEMA = {
    "type": "object",
    "properties": {
        "subject": {"type": "string"},
        "topic": {"type": "string"},
        "total_marks": {"type": "integer"},
        "sections": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "instructions": {"type": "string"},
                    "questions": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "text": {"type": "string"},
                                "marks": {"type": "integer"},
                            },
                            "required": ["text", "marks"],
                        },
                    },
                },
                "required": ["name", "questions"],
            },
        },
    },
    "required": ["subject", "sections"],
}


def question_paper_prompt(subject: str, topic: str, marks: int, difficulty: str) -> str:
    return (
        "Generate an official-style exam paper as JSON matching the "
        "required schema, with three sections: MCQs, Short Answers, and "
        "Long Answers. Distribute the total marks sensibly across "
        "sections.\n\n"
        f"Subject: {subject}\nTopic: {topic}\nTotal marks: {marks}\n"
        f"Difficulty: {difficulty}"
    )

import logging
import os
from logging.handlers import RotatingFileHandler

from flask import Flask

from app.config import get_config
from app.extensions import db, login_manager, csrf, limiter, migrate


def create_app(config_name=None):
    """Application factory. Keeps app.py-style globals out of import time,
    which is what makes testing with a separate test DB actually possible."""
    app = Flask(__name__)
    app.config.from_object(get_config(config_name))

    _init_extensions(app)
    _init_logging(app)
    _register_blueprints(app)
    _register_error_handlers(app)

    return app


def _init_extensions(app):
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"
    login_manager.login_message = "Please log in to continue."
    login_manager.login_message_category = "warning"
    csrf.init_app(app)
    limiter.init_app(app)

    from app.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    @login_manager.unauthorized_handler
    def unauthorized():
        # API requests should get a clean 401 JSON body, not a redirect to
        # /login (which is what flask_login does by default and is useless
        # to a fetch() caller).
        from flask import request, jsonify, redirect, url_for

        if request.path.startswith("/api/"):
            return jsonify({"error": "Please log in first."}), 401
        return redirect(url_for("auth.login"))


def _init_logging(app):
    if app.testing:
        return
    log_dir = os.path.join(app.instance_path, "logs")
    os.makedirs(log_dir, exist_ok=True)
    handler = RotatingFileHandler(
        os.path.join(log_dir, "tutor_me.log"), maxBytes=1_000_000, backupCount=3
    )
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    )
    level = logging.DEBUG if app.debug else logging.INFO
    handler.setLevel(level)
    app.logger.addHandler(handler)
    app.logger.setLevel(level)
    app.logger.info("Tutor Me AI startup (env=%s)", app.config.get("ENV_NAME"))


def _register_blueprints(app):
    from app.blueprints.auth import auth_bp
    from app.blueprints.dashboard import dashboard_bp
    from app.blueprints.tools import tools_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(tools_bp, url_prefix="/api")


def _register_error_handlers(app):
    from flask import jsonify, render_template, request

    @app.errorhandler(413)
    def too_large(e):
        if request.path.startswith("/api/"):
            return jsonify({"error": "File is too large. Max size is 10 MB."}), 413
        return render_template("errors/generic.html", message="File too large."), 413

    @app.errorhandler(429)
    def rate_limited(e):
        if request.path.startswith("/api/"):
            return jsonify({"error": "Too many requests. Please slow down."}), 429
        return render_template("errors/generic.html", message="Too many requests."), 429

    @app.errorhandler(404)
    def not_found(e):
        if request.path.startswith("/api/"):
            return jsonify({"error": "Not found."}), 404
        return render_template("errors/generic.html", message="Page not found."), 404

    @app.errorhandler(500)
    def server_error(e):
        app.logger.exception("Unhandled server error")
        if request.path.startswith("/api/"):
            return jsonify({"error": "Something went wrong on our end."}), 500
        return render_template("errors/generic.html", message="Something went wrong."), 500

// Tutor Me AI — dashboard interactions
// Every fetch() below sends the CSRF token Flask-WTF expects, and every
// piece of AI/user text is inserted with textContent (or built from DOM
// nodes), never innerHTML with raw strings — the one exception is the
// `result` HTML the server already sanitised server-side with bleach.

const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]').content;

function apiFetch(url, options = {}) {
  const headers = Object.assign({ "X-CSRFToken": CSRF_TOKEN }, options.headers || {});
  return fetch(url, { ...options, headers }).then(async (res) => {
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.error || `Request failed (${res.status})`);
    }
    return data;
  });
}

function setLoading(box, messages = ["Thinking..."]) {
  box.className = "result-box loading";
  box.textContent = messages[0];
}

function setError(box, message) {
  box.className = "result-box error";
  box.textContent = message;
}

function setHtml(box, html) {
  // `html` here is server-sanitised (bleach) markdown output, safe to inject.
  box.className = "result-box";
  box.innerHTML = html;
}

// ---------------------------------------------------------------------------
// Tab switching
// ---------------------------------------------------------------------------
document.querySelectorAll(".tool-tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tool-tab").forEach((t) => t.classList.remove("active"));
    document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById(`panel-${tab.dataset.tab}`).classList.add("active");

    if (tab.dataset.tab === "notes") loadNotes();
    if (tab.dataset.tab === "history") loadHistory();
  });
});

// ---------------------------------------------------------------------------
// Simple text-in / html-out tools
// ---------------------------------------------------------------------------
async function runTextTool({ button, box, url, body, formData }) {
  button.disabled = true;
  setLoading(box);
  try {
    const opts = formData
      ? { method: "POST", body: formData }
      : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) };
    const data = await apiFetch(url, opts);
    setHtml(box, data.result);
  } catch (err) {
    setError(box, err.message);
  } finally {
    button.disabled = false;
  }
}

document.querySelector('[data-action="ask"]').addEventListener("click", (e) => {
  const question = document.getElementById("ask-question").value.trim();
  if (!question) return;
  runTextTool({ button: e.target, box: document.getElementById("ask-result"), url: "/api/ask", body: { question } });
});

document.querySelector('[data-action="assignment"]').addEventListener("click", (e) => {
  const fileInput = document.getElementById("assignment-file");
  if (!fileInput.files.length) return;
  const fd = new FormData();
  fd.append("file", fileInput.files[0]);
  fd.append("mode", document.getElementById("assignment-mode").value);
  runTextTool({ button: e.target, box: document.getElementById("assignment-result"), url: "/api/assignment", formData: fd });
});

document.querySelector('[data-action="explain"]').addEventListener("click", (e) => {
  const content = document.getElementById("explain-content").value.trim();
  if (!content) return;
  runTextTool({ button: e.target, box: document.getElementById("explain-result"), url: "/api/explain", body: { content } });
});

document.querySelector('[data-action="summarize"]').addEventListener("click", (e) => {
  const fileInput = document.getElementById("summarize-file");
  if (!fileInput.files.length) return;
  const fd = new FormData();
  fd.append("file", fileInput.files[0]);
  runTextTool({ button: e.target, box: document.getElementById("summarize-result"), url: "/api/summarize-pdf", formData: fd });
});

document.querySelector('[data-action="career"]').addEventListener("click", (e) => {
  const profession = document.getElementById("career-profession").value.trim();
  if (!profession) return;
  const user_type = document.getElementById("career-user-type").value;
  runTextTool({ button: e.target, box: document.getElementById("career-result"), url: "/api/career", body: { profession, user_type } });
});

document.querySelector('[data-action="books"]').addEventListener("click", (e) => {
  const subject = document.getElementById("books-subject").value.trim();
  if (!subject) return;
  runTextTool({ button: e.target, box: document.getElementById("books-result"), url: "/api/books", body: { subject } });
});

document.querySelector('[data-action="tip"]').addEventListener("click", (e) => {
  runTextTool({ button: e.target, box: document.getElementById("tip-result"), url: "/api/tip", body: {} });
});

document.querySelector('[data-action="quote"]').addEventListener("click", (e) => {
  runTextTool({ button: e.target, box: document.getElementById("quote-result"), url: "/api/quote", body: {} });
});

// ---------------------------------------------------------------------------
// MCQ Generator (structured JSON -> built with DOM nodes, not innerHTML)
// ---------------------------------------------------------------------------
document.querySelector('[data-action="mcq"]').addEventListener("click", async (e) => {
  const content = document.getElementById("mcq-content").value.trim();
  if (!content) return;
  const num = document.getElementById("mcq-num").value || 5;
  const box = document.getElementById("mcq-result");
  const button = e.target;

  button.disabled = true;
  setLoading(box);
  try {
    const data = await apiFetch("/api/mcq", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content, num }),
    });
    box.className = "result-box";
    box.innerHTML = "";
    data.questions.forEach((q, i) => {
      const item = document.createElement("div");
      item.className = "mcq-item";

      const qEl = document.createElement("p");
      qEl.textContent = `${i + 1}. ${q.question}`;
      item.appendChild(qEl);

      const optList = document.createElement("ul");
      optList.className = "options";
      q.options.forEach((opt, idx) => {
        const li = document.createElement("li");
        li.textContent = opt;
        if (idx === q.correct_index) li.classList.add("correct");
        optList.appendChild(li);
      });
      item.appendChild(optList);

      const expl = document.createElement("p");
      expl.className = "explanation";
      expl.textContent = q.explanation;
      item.appendChild(expl);

      box.appendChild(item);
    });
  } catch (err) {
    setError(box, err.message);
  } finally {
    button.disabled = false;
  }
});

// ---------------------------------------------------------------------------
// Question Paper Generator (structured JSON -> DOM nodes)
// ---------------------------------------------------------------------------
document.querySelector('[data-action="paper"]').addEventListener("click", async (e) => {
  const subject = document.getElementById("paper-subject").value.trim();
  if (!subject) return;
  const topic = document.getElementById("paper-topic").value.trim() || "General";
  const marks = document.getElementById("paper-marks").value || 50;
  const difficulty = document.getElementById("paper-difficulty").value;
  const box = document.getElementById("paper-result");
  const button = e.target;

  button.disabled = true;
  setLoading(box);
  try {
    const data = await apiFetch("/api/question-paper", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subject, topic, marks, difficulty }),
    });
    const paper = data.paper;
    box.className = "result-box";
    box.innerHTML = "";

    const header = document.createElement("h3");
    header.textContent = `${paper.subject}${paper.topic ? " — " + paper.topic : ""} (${paper.total_marks || marks} marks)`;
    box.appendChild(header);

    (paper.sections || []).forEach((section) => {
      const secTitle = document.createElement("h4");
      secTitle.textContent = section.name;
      box.appendChild(secTitle);

      if (section.instructions) {
        const instr = document.createElement("p");
        instr.className = "explanation";
        instr.textContent = section.instructions;
        box.appendChild(instr);
      }

      const list = document.createElement("ol");
      (section.questions || []).forEach((q) => {
        const li = document.createElement("li");
        li.textContent = `${q.text} [${q.marks} marks]`;
        list.appendChild(li);
      });
      box.appendChild(list);
    });
  } catch (err) {
    setError(box, err.message);
  } finally {
    button.disabled = false;
  }
});

// ---------------------------------------------------------------------------
// Notes
// ---------------------------------------------------------------------------
async function loadNotes() {
  const list = document.getElementById("notes-list");
  list.textContent = "Loading...";
  try {
    const data = await apiFetch("/api/notes");
    list.innerHTML = "";
    if (!data.notes.length) {
      list.textContent = "No notes yet.";
      return;
    }
    data.notes.forEach((n) => list.appendChild(buildNoteItem(n)));
  } catch (err) {
    list.textContent = err.message;
  }
}

function buildNoteItem(note) {
  const item = document.createElement("div");
  item.className = "list-item";

  const del = document.createElement("span");
  del.className = "delete-note";
  del.textContent = "Delete";
  del.addEventListener("click", async () => {
    try {
      await apiFetch(`/api/notes/${note.id}`, { method: "DELETE" });
      item.remove();
    } catch (err) {
      alert(err.message);
    }
  });

  const meta = document.createElement("div");
  meta.className = "meta";
  meta.textContent = note.date;

  const body = document.createElement("p");
  body.textContent = note.content;
  body.style.margin = "0";

  item.appendChild(del);
  item.appendChild(meta);
  item.appendChild(body);
  return item;
}

document.querySelector('[data-action="save-note"]').addEventListener("click", async (e) => {
  const textarea = document.getElementById("note-content");
  const content = textarea.value.trim();
  if (!content) return;
  e.target.disabled = true;
  try {
    await apiFetch("/api/notes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    });
    textarea.value = "";
    loadNotes();
  } catch (err) {
    alert(err.message);
  } finally {
    e.target.disabled = false;
  }
});

// ---------------------------------------------------------------------------
// History
// ---------------------------------------------------------------------------
async function loadHistory() {
  const list = document.getElementById("history-list");
  list.textContent = "Loading...";
  try {
    const data = await apiFetch("/api/history");
    list.innerHTML = "";
    if (!data.history.length) {
      list.textContent = "No history yet — try one of the tools!";
      return;
    }
    data.history.forEach((h) => {
      const item = document.createElement("div");
      item.className = "list-item";

      const meta = document.createElement("div");
      meta.className = "meta";
      meta.textContent = `${h.tool} — ${h.date}`;
      item.appendChild(meta);

      const body = document.createElement("div");
      // response is server-sanitised HTML for free-text tools, plain text otherwise
      body.innerHTML = h.response;
      item.appendChild(body);

      list.appendChild(item);
    });
  } catch (err) {
    list.textContent = err.message;
  }
}

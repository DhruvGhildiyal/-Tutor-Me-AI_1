"""
Single place where extension objects are instantiated but NOT bound to an
app. Binding happens in create_app() via .init_app(). This is what lets us
spin up multiple app instances (e.g. one per pytest test) without global
state leaking between them.
"""
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_migrate import Migrate

db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
csrf = CSRFProtect()
limiter = Limiter(key_func=get_remote_address, default_limits=["200 per day", "50 per hour"])
